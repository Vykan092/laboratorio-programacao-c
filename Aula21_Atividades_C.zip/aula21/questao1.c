#include <stdio.h>

int main(void) {
    FILE *arquivo;
    char nome[50];
    int matricula;
    int i;

    arquivo = fopen("funcionarios.txt", "w");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }

    for (i = 1; i <= 5; i++) {
        printf("\nFuncionario %d\n", i);

        printf("Nome: ");
        scanf(" %49[^\n]", nome);

        printf("Matricula: ");
        scanf("%d", &matricula);

        fprintf(arquivo, "Nome: %s\n", nome);
        fprintf(arquivo, "Matricula: %d\n\n", matricula);
    }

    fclose(arquivo);

    printf("\nDados gravados com sucesso em funcionarios.txt!\n");

    return 0;
}
