#include <stdio.h>

int main() {
    int n = 15;
    int *ptr = &n;
    printf("Antes: %d\n", n);
    *ptr = 50;
    printf("Depois: %d\n", n);
    return 0;
}
