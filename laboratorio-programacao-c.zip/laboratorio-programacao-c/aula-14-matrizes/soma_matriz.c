#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matriz[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    int i, j;
    int soma = 0;

    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            soma += matriz[i][j];
        }
    }

    printf("===== SOMA DA MATRIZ 3x3 =====\n\n");
    printf("Soma de todos os elementos: %d\n", soma);

    return 0;
}
