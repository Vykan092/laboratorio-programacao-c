#include <stdio.h>

typedef struct {
    char nome[50];
    int idade;
    float salario;
} Funcionario;

int main(void) {
    Funcionario funcionario1, funcionario2;
    float diferenca;

    printf("Nome do funcionario 1: ");
    scanf(" %49[^\n]", funcionario1.nome);
    printf("Idade do funcionario 1: ");
    scanf("%d", &funcionario1.idade);
    printf("Salario do funcionario 1: ");
    scanf("%f", &funcionario1.salario);

    printf("\nNome do funcionario 2: ");
    scanf(" %49[^\n]", funcionario2.nome);
    printf("Idade do funcionario 2: ");
    scanf("%d", &funcionario2.idade);
    printf("Salario do funcionario 2: ");
    scanf("%f", &funcionario2.salario);

    printf("\n--- Dados Cadastrados ---\n");
    printf("Funcionario 1: %s | Idade: %d | Salario: %.2f\n", funcionario1.nome, funcionario1.idade, funcionario1.salario);
    printf("Funcionario 2: %s | Idade: %d | Salario: %.2f\n\n", funcionario2.nome, funcionario2.idade, funcionario2.salario);

    if (funcionario1.salario > funcionario2.salario) {
        diferenca = funcionario1.salario - funcionario2.salario;
        printf("Maior salario: %s\n", funcionario1.nome);
        printf("Diferenca salarial: %.2f\n", diferenca);
    } else if (funcionario2.salario > funcionario1.salario) {
        diferenca = funcionario2.salario - funcionario1.salario;
        printf("Maior salario: %s\n", funcionario2.nome);
        printf("Diferenca salarial: %.2f\n", diferenca);
    } else {
        printf("Os dois funcionarios recebem o mesmo salario.\n");
    }

    return 0;
}
