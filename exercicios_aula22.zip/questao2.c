#include <stdio.h>

int main() {
    int x = 20;
    int *p;
    p = &x;
    printf("Valor da variavel: %d\n", x);
    printf("Endereco: %p\n", (void*)p);
    printf("Valor pelo ponteiro: %d\n", *p);
    return 0;
}
