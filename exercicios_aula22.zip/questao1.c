#include <stdio.h>

int main() {
    int num;
    printf("Digite um numero: ");
    scanf("%d", &num);
    printf("Valor: %d\n", num);
    printf("Endereco: %p\n", (void*)&num);
    return 0;
}
