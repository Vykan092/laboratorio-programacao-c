#include <stdio.h>

typedef struct {
    char nome[50];
    float salario;
    int horasExtras;
} Funcionario;

int main(void) {
    FILE *arquivo;
    Funcionario f;
    int opcao;
    int caractere;
    int quantidade;
    int i;

    do {
        printf("\n===== CADASTRO DE FUNCIONARIOS =====\n");
        printf("1 - Cadastrar funcionarios\n");
        printf("2 - Visualizar funcionarios\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("Quantos funcionarios deseja cadastrar (ate 5)? ");
            scanf("%d", &quantidade);

            if (quantidade < 1 || quantidade > 5) {
                printf("Quantidade invalida!\n");
                continue;
            }

            // "a" acrescenta no final sem apagar o que ja existe
            arquivo = fopen("funcionarios.txt", "a");

            if (arquivo == NULL) {
                printf("Erro ao abrir o arquivo!\n");
                continue;
            }

            for (i = 1; i <= quantidade; i++) {
                printf("\nFuncionario %d\n", i);

                printf("Nome: ");
                scanf(" %49[^\n]", f.nome);

                printf("Salario: ");
                scanf("%f", &f.salario);

                printf("Horas extras: ");
                scanf("%d", &f.horasExtras);

                fprintf(arquivo, "Nome: %s\n", f.nome);
                fprintf(arquivo, "Salario: R$ %.2f\n", f.salario);
                fprintf(arquivo, "Horas extras: %d\n", f.horasExtras);
                fprintf(arquivo, "------------------------\n");
            }

            fclose(arquivo);
            printf("\nDados gravados com sucesso!\n");
        }
        else if (opcao == 2) {
            arquivo = fopen("funcionarios.txt", "r");

            if (arquivo == NULL) {
                printf("\nNenhum funcionario cadastrado.\n");
                continue;
            }

            printf("\n===== FUNCIONARIOS CADASTRADOS =====\n");

            while ((caractere = fgetc(arquivo)) != EOF) {
                putchar(caractere);
            }

            fclose(arquivo);
        }
        else if (opcao == 0) {
            printf("\nPrograma encerrado.\n");
        }
        else {
            printf("\nOpcao invalida!\n");
        }

    } while (opcao != 0);

    return 0;
}
